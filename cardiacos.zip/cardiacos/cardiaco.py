import streamlit as st
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import PredictionErrorDisplay, accuracy_score
from sklearn.model_selection import train_test_split
from PIL import Image

# Título de la aplicación
st.title("Predicción de problemas cardiacos")

# Cargar el conjunto de datos
datos = pd.read_csv("data/ataquesC.csv")

# Dividir los datos en características (X) y objetivo (Y)
X = datos.drop("target", axis=1)
Y = datos["target"]

# Dividir los datos en entrenamiento y prueba
X_entrenamiento, X_prueba, Y_entrenamiento, Y_prueba = train_test_split(X, Y, test_size=0.35, random_state=42)

# Entrenar el modelo
clf = RandomForestClassifier(n_estimators=100, max_depth=5, random_state=42)
clf.fit(X_entrenamiento, Y_entrenamiento)



# Obtener la entrada del usuario y realizar la predicción
def obtener_entrada_usuario():
    age = st.slider("Edad", min_value=0, max_value=100, value=50)
    cp = st.selectbox("Tipo de dolor en el pecho", [0, 1, 2, 3])
    trestbps = st.slider("Presión arterial en reposo", min_value=0, max_value=300, value=120)
    chol = st.slider("Colesterol en mg/dl", min_value=0, max_value=600, value=200)
    fbs = st.selectbox("Nivel de azúcar en sangre en ayunas", [0, 1])
    restecg = st.selectbox("Resultados electrocardiográficos en reposo", [0, 1, 2])
    thalach = st.slider("Frecuencia cardíaca máxima alcanzada", min_value=0, max_value=250, value=150)
    exang = st.selectbox("Angina inducida por el ejercicio", [0, 1])
    oldpeak = st.slider("Depresión del ST inducida por el ejercicio", min_value=0.0, max_value=10.0, value=0.0)
    slope = st.selectbox("La pendiente del segmento ST de ejercicio pico", [0, 1, 2])
    ca = st.slider("Número de vasos principales coloreados por la fluoroscopia", min_value=0, max_value=4, value=0)
    thal = st.selectbox("Defecto de talasemia", [0, 1, 2, 3])

    return pd.DataFrame({
        "age": [age],
        "cp": [cp],
        "trestbps": [trestbps],
        "chol": [chol],
        "fbs": [fbs],
        "restecg": [restecg],
        "thalach": [thalach],
        "exang": [exang],
        "oldpeak": [oldpeak],
        "slope": [slope],
        "ca": [ca],
        "thal": [thal]
    })

# Realizar la predicción y mostrar resultados
def predecir_problemas_cardiacos(entrada):
    prediccion = clf.predict(entrada)
    probabilidad = clf.predict_proba(entrada)[:, 1]
    if prediccion[0] == 1:
        resultado = "Puede sufrir ataque cardíaco"
        imagen = Image.open("img/sufre.jpeg")  # Ruta de la imagen para ataque cardíaco
    else:
        resultado = "No sufre ataque cardíaco"
        imagen = Image.open("img/noSufre.jpeg")  # Ruta de la imagen para no ataque cardíaco
    return resultado, probabilidad[0], imagen

# Interfaz de usuario
entrada_usuario = obtener_entrada_usuario()
resultado, probabilidad, imagen = predecir_problemas_cardiacos(entrada_usuario)

col1, col2 = st.columns(2)

# Mostrar el menú de usuario en la primera columna
with col1:
    st.write("## DATOS INGRESADOS")
    st.write("Edad:", entrada_usuario["age"].values[0])
    st.write("Tipo de dolor en el pecho:", entrada_usuario["cp"].values[0])
    st.write("Presión arterial en reposo:", entrada_usuario["trestbps"].values[0])
    st.write("Colesterol en mg/dl:", entrada_usuario["chol"].values[0])
    st.write("Nivel de azúcar en sangre en ayunas:", entrada_usuario["fbs"].values[0])
    st.write("Resultados electrocardiográficos en reposo:", entrada_usuario["restecg"].values[0])
    st.write("Frecuencia cardíaca máxima alcanzada:", entrada_usuario["thalach"].values[0])
    st.write("Angina inducida por el ejercicio:", entrada_usuario["exang"].values[0])
    st.write("Depresión del ST inducida por el ejercicio:", entrada_usuario["oldpeak"].values[0])
    st.write("La pendiente del segmento ST de ejercicio pico:", entrada_usuario["slope"].values[0])
    st.write("Número de vasos principales coloreados por la fluoroscopia:", entrada_usuario["ca"].values[0])
    st.write("Defecto de talasemia:", entrada_usuario["thal"].values[0])
   
# Mostrar los resultados de la predicción y la imagen en la segunda columna
with col2:
    st.write("## Resultado de la predicción")
    st.write("Predicción:", resultado)
    st.write("Probabilidad:", probabilidad)
    st.image(imagen, caption=f"La persona tiene una probabilidad del {probabilidad*100}% de sufrir un ataque cardíaco.", use_column_width=True)
    st.markdown("---")

    
    